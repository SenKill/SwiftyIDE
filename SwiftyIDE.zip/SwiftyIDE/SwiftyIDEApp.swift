//
//  SwiftyIDEApp.swift
//  SwiftyIDE
//
//  Created by Serik Musaev on 07.03.2025.
//

import SwiftUI

@main
struct SwiftyIDEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
