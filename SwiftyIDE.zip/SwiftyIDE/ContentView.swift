//
//  ContentView.swift
//  SwiftyIDE
//
//  Created by Serik Musaev on 07.03.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CodeEditorView()
    }
}

#Preview {
    ContentView()
}
